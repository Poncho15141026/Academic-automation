#!/usr/bin/env python3
"""Valida la estructura básica de los flujos de n8n guardados en workflows/.

Revisa que cada archivo sea JSON válido, que los nodos tengan los campos
mínimos, que no haya nombres repetidos, que exista un disparador y que todas
las conexiones apunten a nodos que existen.

Uso:  python scripts/validate_workflows.py
"""
import json
import pathlib
import sys

CAMPOS_NODO = ("name", "type", "typeVersion", "position", "parameters")


def validar(ruta: pathlib.Path) -> list[str]:
    errores: list[str] = []
    try:
        wf = json.loads(ruta.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        return [f"JSON inválido: {e}"]

    nodos = wf.get("nodes", [])
    if not nodos:
        return ["el flujo no tiene nodos"]

    nombres = [n.get("name") for n in nodos]
    if len(nombres) != len(set(nombres)):
        errores.append("hay nombres de nodo repetidos")

    for n in nodos:
        for campo in CAMPOS_NODO:
            if campo not in n:
                errores.append(f"el nodo '{n.get('name', '?')}' no tiene '{campo}'")

    if not any(
        n.get("type", "").lower().endswith(("trigger", "webhook")) for n in nodos
    ):
        errores.append("no hay ningún nodo disparador (trigger/webhook)")

    for origen, salidas in wf.get("connections", {}).items():
        if origen not in nombres:
            errores.append(f"conexión desde un nodo inexistente: '{origen}'")
        for lista in salidas.get("main", []):
            for enlace in lista:
                if enlace.get("node") not in nombres:
                    errores.append(
                        f"'{origen}' apunta a un nodo inexistente: '{enlace.get('node')}'"
                    )
    return errores


def main() -> int:
    carpeta = pathlib.Path(__file__).resolve().parent.parent / "workflows"
    archivos = sorted(carpeta.glob("*.json"))
    if not archivos:
        print("No se encontraron flujos en workflows/")
        return 1

    hubo_errores = False
    for ruta in archivos:
        errores = validar(ruta)
        if errores:
            hubo_errores = True
            print(f"ERROR  {ruta.name}")
            for e in errores:
                print(f"       - {e}")
        else:
            print(f"OK     {ruta.name}")
    return 1 if hubo_errores else 0


if __name__ == "__main__":
    sys.exit(main())
