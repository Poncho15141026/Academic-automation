# 📚 Academic Automation Hub

Flujos automatizados en **n8n** que organizan el seguimiento de tareas y entregas académicas: capturan tareas desde cualquier lugar, avisan lo que vence pronto y mandan un resumen semanal de avance. Todo corre en local con Docker y se conecta a **Google Sheets** y **Telegram**.

El objetivo es eliminar el trabajo manual repetitivo de revisar fechas, anotar pendientes y armar resúmenes a mano.

## ¿Qué hace?

| Flujo | Disparador | Qué hace |
|---|---|---|
| `01-recordatorio-entregas` | Todos los días a las 8:00 | Lee la hoja, filtra tareas no terminadas que vencen en los próximos `DIAS_AVISO` días (o ya vencieron) y manda el aviso por Telegram. Si no hay nada urgente, no envía nada. |
| `02-captura-tareas-webhook` | `POST /webhook/tarea` | Recibe una tarea por HTTP, valida los datos (campos obligatorios, fecha real, prioridad), la guarda en la hoja y responde `200` o `400` con el motivo. |
| `03-resumen-semanal` | Lunes a las 8:00 | Calcula avance general, pendientes, vencidas, entregas de la semana y carga por materia, y lo envía por Telegram. |

## Arquitectura

```mermaid
flowchart LR
  A["Formulario / app / curl"] -->|"POST /webhook/tarea"| W["Flujo 02: captura"]
  W -->|append| S[("Google Sheets: tareas")]
  S --> R["Flujo 01: recordatorio diario"]
  S --> M["Flujo 03: resumen semanal"]
  R --> T["Telegram"]
  M --> T
```

Decisiones de diseño:

- **Google Sheets como fuente de verdad**: se puede editar a mano desde el celular y no requiere base de datos.
- **Lógica en nodos Code**: el filtrado, las fechas y el formato de los mensajes viven en JavaScript legible y probado, no en cadenas de nodos difíciles de mantener.
- **Configuración por variables de entorno**: ningún ID ni token va escrito en los flujos, por lo que el repositorio es seguro de publicar.
- **CI**: un workflow de GitHub Actions valida la estructura de los JSON en cada push.

## Requisitos

- Docker y Docker Compose
- Una cuenta de Google (para Google Sheets)
- Un bot de Telegram (gratis, se crea en un minuto con [@BotFather](https://t.me/BotFather))

## Instalación

### 1. Clonar y configurar

```bash
git clone https://github.com/<tu-usuario>/academic-automation-hub.git
cd academic-automation-hub
cp .env.example .env
```

### 2. Crear la hoja de cálculo

1. Crea un Google Sheet con una pestaña llamada **`tareas`**.
2. Importa `data/tareas_ejemplo.csv` (Archivo → Importar) o copia sus encabezados: `id, materia, tarea, fecha_entrega, prioridad, estado, creada_en`.
3. Formatea la columna `fecha_entrega` como **texto sin formato** (Formato → Número → Texto sin formato). Los flujos aceptan `AAAA-MM-DD` y `DD/MM/AAAA`.
4. Copia el ID de la hoja (lo que va entre `/d/` y `/edit` en la URL) a `SHEET_ID` en `.env`.

Valores válidos de `estado`: `Pendiente`, `En progreso`, `Hecha`. Las tareas marcadas como `Hecha` se excluyen de los avisos.

### 3. Crear el bot de Telegram

1. Habla con [@BotFather](https://t.me/BotFather), usa `/newbot` y guarda el token.
2. Escríbele `/start` a tu bot nuevo.
3. Obtén tu chat ID con [@userinfobot](https://t.me/userinfobot) y ponlo en `TELEGRAM_CHAT_ID` en `.env`.

### 4. Levantar n8n

```bash
docker compose up -d
```

Abre <http://localhost:5678> y crea tu cuenta de administrador local.

### 5. Credenciales e importación

1. En n8n ve a **Credentials** y crea:
   - **Google Sheets OAuth2 API** (guía oficial: [Google credentials](https://docs.n8n.io/integrations/builtin/credentials/google/)). La URL de redirección en local es `http://localhost:5678/rest/oauth2-credential/callback`.
   - **Telegram API** con el token de tu bot.
2. Ve a **Workflows → Import from file** e importa los tres archivos de `workflows/`.
3. En cada flujo abre los nodos de Google Sheets y Telegram y selecciona tus credenciales.
4. En el flujo 02, abre el nodo **Guardar en Google Sheets** y pulsa el botón de refrescar columnas para que n8n lea los encabezados de tu hoja.
5. Prueba cada flujo con **Execute workflow** y después actívalos.

## Probar la captura por webhook

Con el flujo 02 activo:

```bash
curl -X POST http://localhost:5678/webhook/tarea \
  -H "Content-Type: application/json" \
  -d '{"materia":"Cálculo","tarea":"Taller 5","fecha_entrega":"2026-11-03","prioridad":"alta"}'
# → {"ok":true,"id":1790000000000}
```

Si estás probando con **Listen for test event**, usa `/webhook-test/tarea` en lugar de `/webhook/tarea`.

Ejemplo de error de validación:

```bash
curl -X POST http://localhost:5678/webhook/tarea \
  -H "Content-Type: application/json" \
  -d '{"materia":"Física","tarea":"Lab","fecha_entrega":"2026-02-31"}'
# → {"ok":false,"error":"fecha_entrega debe tener formato AAAA-MM-DD y ser una fecha real"}
```

## Ejemplo de salida

Recordatorio diario:

```text
📚 Entregas que requieren atención

🔴 Bases de datos: Diagrama entidad-relación (vencida hace 1 d)
🟡 Cálculo: Taller de derivadas (mañana)
🟡 Programación: Proyecto final API (en 3 días)
```

Resumen semanal:

```text
🗓️ Resumen semanal

Avance general: 1/6 tareas hechas (17%)
Pendientes: 5 · Vencidas: 1

Para esta semana:
• jue 15/10 — Cálculo: Taller de derivadas
• sáb 17/10 — Programación: Proyecto final API
```

## Configuración

| Variable | Descripción |
|---|---|
| `SHEET_ID` | ID del Google Sheet con la pestaña `tareas` |
| `TELEGRAM_CHAT_ID` | Chat donde llegan los avisos |
| `DIAS_AVISO` | Días de anticipación del recordatorio diario (por defecto 3) |
| `GENERIC_TIMEZONE` / `TZ` | Zona horaria de los disparadores |

## Estructura del repositorio

```text
.
├── workflows/                 # Flujos de n8n listos para importar
├── data/tareas_ejemplo.csv    # Datos de ejemplo para la hoja
├── scripts/validate_workflows.py
├── .github/workflows/validate.yml
├── docker-compose.yml
└── .env.example
```

## Validación

```bash
python scripts/validate_workflows.py
```

Comprueba que cada JSON sea válido, que no haya nodos repetidos, que exista un disparador y que todas las conexiones apunten a nodos reales. Se ejecuta automáticamente en GitHub Actions.

## Ideas para seguir

- Resumen y plan de estudio generado con un modelo de lenguaje a partir de las tareas pendientes.
- Sincronizar las entregas con Google Calendar.
- Importar fechas desde el correo (syllabus, avisos de la plataforma del curso).
- Botones en Telegram para marcar una tarea como hecha.

## Licencia

MIT. Consulta el archivo [LICENSE](LICENSE).
